H4 ERP - installable app (PWA)
Upload ALL of these into the root of your GitHub Pages repo (avchemtirur.github.io):
  index.html
  manifest.webmanifest
  sw.js
  icons/ (whole folder: 6 png files)
Then open https://avchemtirur.github.io/ in Chrome on the phone:
  - an "Install H4 ERP on this phone" card appears on the Home screen -> tap Install
  - or Chrome menu (3 dots) -> Install app / Add to Home screen
The app then has its own icon and opens full-screen. Your data stays in the phone.
iPhone: Safari -> Share -> Add to Home Screen.
